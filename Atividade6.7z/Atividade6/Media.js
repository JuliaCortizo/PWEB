function calculaMedia(){
    let nota1 = parseFloat(prompt("Entre com a nota 1: "));
    let nota2 = parseFloat(prompt("Entre com a nota 2: "));
    let nota3 = parseFloat(prompt("Entre com a nota 3: "));

    let media = (nota1 + nota2 + nota3) / 3;  
    alert(media);
}

